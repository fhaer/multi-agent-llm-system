# Multi-Agent LLM System

Prototype implementation of a multi-agent LLM system with execution based on a defined specification format.

The prototype supports code generation with OpenAI GPT-4o, OpenAI o1-preview, DeepSeek-R1, DeepSeek-R1-Distilled-Llama-8B.

Note: The prototype is only intended as a feasibility demonstration.

Requirements: 
- Python 3.12 with the packages listed in requirements.txt, in a virtual environment
- API keys for OpenAI and/or Replicate to be set with the "-a" option are shown below
- For local inference, an Ollama endpoint is needed and must be set with the "-a" option
- Host execution environment: the example specification assumes Ubuntu 24.04 and requires Python 3.12, shellcheck, and pylint for syntax checks

Usage, parameters and further details:

```
> python3 llm-agents.py --help
LA Test Environment v0.1

Usage: llm-agents.py [-h|--help] [-s|--schema-file <path>] [-a|--api <api_id>:<api_key>[:api_endpoint]]* [-p|--port <ui_port>]

<api_id> = OpenAI | Replicate | Ollama

Supported LLM Clients:
- OpenAI
- Replicate
- Ollama

Example Usage:
- Run with agent schema file schema.json, API keys for OpenAI and Replicate:
  cmi.py -s schema.json -a OpenAI:INSERT_KEY -a Replicate:INSERT_KEY
- Run with agent schema file schema.json, a local Ollama endpoint:
  cmi.py -s schema.json -a Ollama::'http://127.0.0.1:11434/api'
  
The web-based UI will be started at port <ui_port>, the default is 8501.
```

#### Related Publication

Outstanding.
