import sys
import time
import uuid
import json
import requests

from time import perf_counter_ns
from io import StringIO

import streamlit as st
from streamlit.web import cli as stweb

import conversation.conversation_manager as conversation_manager
import conversation.agent_manager as agent_manager
import agent_execution.execution_engine as execution_engine

SESSION_KEY_RUN_AGENT = "agent/"

SESSION_KEY_MESSAGES = "messages/"
SESSION_KEY_CONTEXT_IDS = "context_ids/"

SESSION_KEY_LLM_UI_INPUT = "ui/input/llm/"

SESSION_KEY_NEXT_AGENT_LLM = "agent-llm/"
SESSION_KEY_NEXT_USER_PROMPT = "prompt/message"

AGENT_ID = "agent-id"
AGENT_ID_INIT = "undefined"

ROLE = "role"
ROLE_AS = "assistant"
ROLE_US = "user"
ROLE_IN = "interpreter"
ROLE_SYS = "system"

MSG = "message"
SRC = "source"
MSG_FORMAT = "format"
MSG_FORMAT_INIT = "in"
MSG_FORMAT_PROMPT = "pr"
MSG_FORMAT_RESPONSE_LLM = "re/llm"
MSG_FORMAT_RESPONSE_LLM_TXT = "re/llm/txt"
MSG_FORMAT_RESPONSE_LLM_CODE = "re/llm/code"
MSG_FORMAT_RESPONSE_INT = "re/int"
MSG_FORMAT_RESPONSE_INT_TXT = "re/int/txt"
MSG_FORMAT_RESPONSE_INT_IMG = "re/int/img"
MSG_RERUN_LLM = "rerun/llm"
MSG_RERUN_INT = "rerun/int"

INIT_MSG = ""
SYS_PROMPT_DEFAULT = "You are a helpful assistant."

AVATAR = "avatar"
AVATAR_AS = "A"
AVATAR_US= "U"
AVATAR_IN = "I"
AVATAR_SYS = "S"

class ConversationalUI:
    """Web UI of the conversational interface using Streamlit"""

    def __init__(self, ui_port, ui_init_message, api_keys, conversation_manager, agent_manager):
        print("Load Conversational UI ...")
        self.ui_port = ui_port
        self.ui_init_message = ui_init_message
        self.api_keys = api_keys
        self.conversation_manager = conversation_manager
        self.agent_manager = agent_manager
        self.message_id = 0
        self.ui_title = "MAR"

    def set_available_llms(self, models):
        self.available_llms = models

    def set_available_functions(self, functions):
        self.available_functions = functions

    def trigger_update(self, message):
        st.toast(message)
        st.rerun()

    def update_web_ui(self):
        """Updates the web UI with selectable agents, LLMs, current parameters, and messages of the conversation"""

        # App title
        st.set_page_config(page_title=self.ui_title)
        
        # Initialize session storage for messages and prompts
        if SESSION_KEY_RUN_AGENT not in st.session_state.keys():
            st.session_state[SESSION_KEY_RUN_AGENT] = ""
        if SESSION_KEY_MESSAGES not in st.session_state.keys():
            st.session_state[SESSION_KEY_MESSAGES] = [ ]
        if SESSION_KEY_NEXT_USER_PROMPT not in st.session_state.keys():
            st.session_state[SESSION_KEY_NEXT_USER_PROMPT] = ""
        if SESSION_KEY_NEXT_AGENT_LLM not in st.session_state.keys():
            st.session_state[SESSION_KEY_NEXT_AGENT_LLM] = ""
        if MSG_RERUN_LLM not in st.session_state.keys():
            st.session_state[MSG_RERUN_LLM] = False
        if MSG_RERUN_INT not in st.session_state.keys():
            st.session_state[MSG_RERUN_INT] = ""

        # Remove all messages
        def clear_chat_history():
            st.session_state[SESSION_KEY_MESSAGES] = [ ]
            self.conversation_manager.clear_chat_history(INIT_MSG)

        # Enables displaying the file uploader in the chat
        def remove_last_prompt_and_response():
            # remove response (from LLM, interpreter)
            while len(st.session_state[SESSION_KEY_MESSAGES]) > 0 and st.session_state[SESSION_KEY_MESSAGES][-1][ROLE] != ROLE_US:
                st.session_state[SESSION_KEY_MESSAGES] = st.session_state[SESSION_KEY_MESSAGES][0:-1]
                self.conversation_manager.remove_last_message()
            # remove last user message
            while len(st.session_state[SESSION_KEY_MESSAGES]) > 0 and st.session_state[SESSION_KEY_MESSAGES][-1][ROLE] == ROLE_US:
                st.session_state[SESSION_KEY_MESSAGES] = st.session_state[SESSION_KEY_MESSAGES][0:-1]
                self.conversation_manager.remove_last_message()

        # Prepare a schema for execution
        def activate_schema(schema_contents):
            init_agent_id = self.agent_manager.setup_agents(schema_contents)
            self.selected_agent = init_agent_id

        # Initialize the selected LLM prior to execution
        def initialize_llm():
            st.session_state[SESSION_KEY_NEXT_AGENT_LLM] = st.session_state.selected_llm

        # Initialize the LLM specified by an agent prior to execution
        def initialize_llm_by_agent(agent):
            llm_config = self.agent_manager.get_llm_configuration(agent["llm-configuration"])
            if not llm_config:
                raise Exception("LLM configuration undefined for agent:", agent)
            st.session_state[SESSION_KEY_NEXT_AGENT_LLM] = llm_config.get("llm", None)

        # Initialize an agent prior to execution
        def initialize_agent_by_id(agent_id):
            self.agent_manager.initialize_agent(agent_id)
            agent = self.agent_manager.get_agent()
            initialize_llm_by_agent(agent)

        # Initialize the selected agent prior to execution
        def initialize_agent():
            initialize_agent_by_id(st.session_state.selected_agent)
            
        # Activate an agent
        def activate_agent_by_id(agent_id):

            clear_chat_history()
            st.session_state[SESSION_KEY_RUN_AGENT] = agent_id

        # Activate the selected agent
        def activate_agent():
            activate_agent_by_id(st.session_state.selected_agent)

        # At the next UI update, run the given prompt
        def schedule_llm_prompt_for_next_run(message):
            st.session_state[SESSION_KEY_NEXT_USER_PROMPT] = message
       
        # Enables displaying the file uploader
        def show_file_uploader():
            if not "file_uploader_visible" in st.session_state or not st.session_state["file_uploader_visible"]:
                st.session_state["show_file_uploader"] = True
                
        # Disables displaying the file uploader
        def hide_file_uploader():
            st.session_state["show_file_uploader"] = False

        def insert_llm_response(llm_response, source, allow_rerun=True, placeholder=None):
            if placeholder is None:
                #with st.expander("LLM Response", expanded=True):
                placeholder = st.empty()
                placeholder.markdown(llm_response)
                            
            self.message_id += 1

            if source is None:
                if allow_rerun:
                    st.session_state[MSG_RERUN_INT] = None
                    if self.conversation_manager.is_int_selected():
                        with st.expander("Edit LLM Response"):
                            st.session_state[MSG_RERUN_INT] = st.text_area("Edit:", height=400, value=llm_response.lstrip())
                        st.markdown("No model source code could be parsed from the LLM Response. Please re-run the LLM or edit the response and re-run the interpreter.")
            else:
                st.session_state[MSG_RERUN_INT] = None

        # Execute prompt
        def run_llm(prompt, agent):
            llm_response = ''
            execution_duration = 0

            context = st.session_state[SESSION_KEY_MESSAGES]

            with st.chat_message(ROLE_AS):
                # start inference and stream response
                with st.spinner(f"Running Inference: {selected_llm} ..."):
                    # get reponse items and un-wrap using the provided function
                    items_wrapped = []
                    item_function = lambda item: item
                    try:
                        (items_wrapped, item_function, t_start) = self.conversation_manager.enter_prompt(context, prompt)
                        placeholder = st.empty()
                        for item in items_wrapped:
                            llm_response += item_function(item)
                            placeholder.markdown(llm_response + "▌")
                        t_stop = perf_counter_ns()
                        execution_duration = (t_stop-t_start)
                        print("LLM total execution duration [ns]:", execution_duration)
                        # get and store source
                        #source = self.conversation_manager.process_llm_response(llm_response)
                        #st.session_state[SESSION_KEY_MESSAGES][-1][SRC] = source
                        # show response
                        #insert_llm_response(llm_response, source, placeholder=placeholder)
                    except requests.exceptions.ChunkedEncodingError as e:
                        placeholder.markdown(e)
                        st.button("Retry", on_click=remove_responses_and_rerun_llm, key="retry/llm/placeholder/error")

            # append response to session state
            message = {ROLE: ROLE_AS, MSG: llm_response, MSG_FORMAT: MSG_FORMAT_RESPONSE_LLM_TXT, AGENT_ID: agent}
            st.session_state[SESSION_KEY_MESSAGES].append(message)

            return (llm_response, execution_duration)

        # Insert interpreter response
        def insert_int_response(int_input, int_output=None, text_message=None, allow_rerun=True, placeholder=None):

            if placeholder is None:
                placeholder = st.empty()

            self.message_id += 1

            #st.session_state[MSG_RERUN_INT] = None
            if int_input:
                with st.expander("Model Source Code"):
                    if allow_rerun:
                        st.session_state[MSG_RERUN_INT] = st.text_area("Edit:", height=400, value=int_input)
                    else:
                        st.markdown(f"```\n{int_input}\n```")
                if allow_rerun:
                    if self.conversation_manager.is_int_selected():
                        st.button("Re-run interpreter", on_click=remove_int_response_and_rerun_int, key="retry/int/" + str(self.message_id), use_container_width=True, disabled=(not self.conversation_manager.is_int_selected()))

            if int_output:
                placeholder.text(self.conversation_manager.selected_int_id)
                placeholder.image(int_output)

            if text_message:
                placeholder.write(text_message)

        # Submit user-provided prompt
        def submit_user_prompt():

            if not self.conversation_manager.is_llm_selected():
                st.session_state[SESSION_KEY_NEXT_USER_PROMPT] = ""
                st.session_state[SESSION_KEY_RUN_AGENT] = ""

            agent_id = ""
            prompt_msg = ""
            sys_prompt_msg = ""

            if st.session_state[SESSION_KEY_NEXT_USER_PROMPT]:
                
                agent_id = "User"
                prompt_msg = st.session_state[SESSION_KEY_NEXT_USER_PROMPT]
                st.session_state[SESSION_KEY_NEXT_USER_PROMPT] = ""
                sys_prompt_msg = SYS_PROMPT_DEFAULT

            elif st.session_state[SESSION_KEY_RUN_AGENT]:

                if self.agent_manager.has_agent_prompt():
                    (agent, prompt) = self.agent_manager.get_agent_prompt()
                    agent_id = agent["id"]
                    prompt_msg = prompt["prompt"]
                    sys_prompt_msg = agent["system-prompt"]

            if prompt_msg:

                if not st.session_state[MSG_RERUN_LLM]:
                    if len(st.session_state[SESSION_KEY_MESSAGES]) == 0:
                        st.session_state[SESSION_KEY_MESSAGES].append({ ROLE: ROLE_SYS, MSG: sys_prompt_msg, MSG_FORMAT: MSG_FORMAT_PROMPT, AGENT_ID:agent_id })
                        with st.chat_message(ROLE_SYS):
                            # write message, insert spaces before newlines to comply with markdown format
                            st.write(sys_prompt_msg.replace("\n", "  \n"))
                    st.session_state[SESSION_KEY_MESSAGES].append({ ROLE: ROLE_US, MSG: prompt_msg, MSG_FORMAT: MSG_FORMAT_PROMPT, AGENT_ID:agent_id })
                    # display prompt message
                    with st.chat_message(ROLE_US):
                        # write message, insert spaces before newlines to comply with markdown format
                        st.write(prompt_msg.replace("\n", "  \n"))
                st.session_state[MSG_RERUN_LLM] = False

                # run llm
                (response, llm_execution_duration) = run_llm(prompt_msg, agent_id)
                self.conversation_manager.record_llm_response(response, llm_execution_duration)
                #llm_response = self.conversation_manager.process_llm_response(llm_response)
                if st.session_state[SESSION_KEY_RUN_AGENT]:
                    (output, data, append_output) = self.agent_manager.execute_actions(response)
                    (result_class, evaluation) = self.agent_manager.evaluate_result(output, data)
                    # append output in context after LLM response
                    if append_output:
                        response += "\n\nResult:\n" + output
                st.session_state[SESSION_KEY_MESSAGES][-1][SRC] = response
                
                # run on response
                if st.session_state[SESSION_KEY_RUN_AGENT]:

                    # Continue execution
                    if self.agent_manager.has_next_agent_prompt():

                        prev_agent = self.agent_manager.get_agent()
                        self.agent_manager.set_next_agent_prompt()
                        agent = self.agent_manager.get_agent()

                        initialize_llm_by_agent(agent)
                        if agent != prev_agent:
                            activate_agent_by_id(agent["id"])
                    else:
                        # Finish execution
                        (agent_id, prompt_id) = self.agent_manager.remove_agent_prompt()
                        self.agent_manager.write_result_classes_evaluations()
                        st.session_state[SESSION_KEY_RUN_AGENT] = ""
                        # Continue batch processing
                        next_agent_id = self.agent_manager.get_next_alphabetical_agent_id(agent_id)
                        #if next_agent_id:
                        #    print("\n\nContinue with next agent specification ...\n\n")
                        #    initialize_agent_by_id(next_agent_id)
                        #    activate_agent_by_id(next_agent_id)

                st.rerun()

        # Remove the last interpreter and LLM answers and re-run the LLM and interpreter
        def remove_responses_and_rerun_llm():
            # remove response (from interpreter)
            while len(st.session_state[SESSION_KEY_MESSAGES]) > 0 and st.session_state[SESSION_KEY_MESSAGES][-1][MSG_FORMAT].startswith(MSG_FORMAT_RESPONSE_INT):
                st.session_state[SESSION_KEY_MESSAGES] = st.session_state[SESSION_KEY_MESSAGES][0:-1]
                self.conversation_manager.remove_last_message()
            # remove response (from LLM)
            while len(st.session_state[SESSION_KEY_MESSAGES]) > 0 and st.session_state[SESSION_KEY_MESSAGES][-1][MSG_FORMAT].startswith(MSG_FORMAT_RESPONSE_LLM):
                st.session_state[SESSION_KEY_MESSAGES] = st.session_state[SESSION_KEY_MESSAGES][0:-1]
                self.conversation_manager.remove_last_message()
            # get last prompt and re-run
            if st.session_state[SESSION_KEY_MESSAGES][-1][MSG_FORMAT] == MSG_FORMAT_PROMPT:
                last_prompt = st.session_state[SESSION_KEY_MESSAGES][-1][MSG]
                st.session_state[MSG_RERUN_LLM] = True
                schedule_llm_prompt_for_next_run(last_prompt)

        # Remove the last interpreter response and re-run the interpreter
        def remove_int_response_and_rerun_int():
            if self.conversation_manager.is_int_selected():
                int_input = st.session_state[MSG_RERUN_INT]
                # remove response (from interpreter)
                while len(st.session_state[SESSION_KEY_MESSAGES]) > 0 and st.session_state[SESSION_KEY_MESSAGES][-1][MSG_FORMAT].startswith(MSG_FORMAT_RESPONSE_INT):
                    st.session_state[SESSION_KEY_MESSAGES] = st.session_state[SESSION_KEY_MESSAGES][0:-1]
                    self.conversation_manager.remove_last_message()
                # set interpreter input and re-run
                if st.session_state[SESSION_KEY_MESSAGES][-1][MSG_FORMAT].startswith(MSG_FORMAT_RESPONSE_LLM):
                    # store input as source code
                    st.session_state[SESSION_KEY_MESSAGES][-1][SRC] = int_input


        # Sidebar for parameter configuration
        with st.sidebar:
            #st.title(self.ui_title)
            st.info(self.ui_init_message)
            st.subheader('Agent')

            # Agent and LLM selection
            if st.session_state[SESSION_KEY_RUN_AGENT]:
                st.session_state.selected_agent = st.session_state[SESSION_KEY_RUN_AGENT]
                if st.session_state[SESSION_KEY_NEXT_AGENT_LLM]:
                    st.session_state.selected_llm = st.session_state[SESSION_KEY_NEXT_AGENT_LLM]
            if st.session_state[SESSION_KEY_NEXT_AGENT_LLM]: # and st.session_state.selected_llm == conversation_manager.LLM_UNSELECTED:
                st.session_state.selected_llm = st.session_state[SESSION_KEY_NEXT_AGENT_LLM]

            selected_llm = st.sidebar.selectbox(
                'Agent Settings', 
                sorted(self.agent_manager.get_agents()), 
                key='selected_agent',
                on_change=initialize_agent
                )
            
            selected_llm = st.sidebar.selectbox(
                'LLM Settings', 
                sorted(self.available_llms.keys()), 
                key='selected_llm',
                on_change=initialize_llm)
            
            llm_selected_new = self.conversation_manager.select_llm(selected_llm)
            
            llm_param_binding = self.conversation_manager.set_llm_parameters(INIT_MSG)
            
            # Create LLM UI controls
            for p in llm_param_binding.keys():
                if llm_selected_new:
                    st.session_state[SESSION_KEY_LLM_UI_INPUT + p] = self.conversation_manager.llm_parameters_default[p]
                if p == 'temperature':
                    llm_param_binding[p] = st.sidebar.slider(p, min_value=0.01, max_value=5.0, step=0.01, key=SESSION_KEY_LLM_UI_INPUT + p)
                elif p == 'top_p':
                    llm_param_binding[p] = st.sidebar.slider(p, min_value=0.01, max_value=1.0, step=0.01, key=SESSION_KEY_LLM_UI_INPUT + p)
                elif p == 'top_k':
                    llm_param_binding[p] = st.sidebar.number_input(p, min_value=1, step=1, key=SESSION_KEY_LLM_UI_INPUT + p)
                elif p == 'max_new_tokens' or p == 'n_tokens_max':
                    llm_param_binding[p] = st.sidebar.number_input(p, min_value=64, step=8, key=SESSION_KEY_LLM_UI_INPUT + p)
                elif p == 'min_new_tokens':
                    llm_param_binding[p] = st.sidebar.number_input(p, min_value=-1, step=1, key=SESSION_KEY_LLM_UI_INPUT + p)
                elif p == 'frequency_penalty':
                    llm_param_binding[p] = st.sidebar.slider(p, min_value=-2.0, max_value=2.0, step=0.01, key=SESSION_KEY_LLM_UI_INPUT + p)
                elif p == 'presence_penalty':
                    llm_param_binding[p] = st.sidebar.slider(p, min_value=-2.0, max_value=2.0, step=0.01, key=SESSION_KEY_LLM_UI_INPUT + p)

                else:
                    if isinstance(llm_param_binding[p], int):
                        llm_param_binding[p] = st.sidebar.number_input(p, step=1, key=SESSION_KEY_LLM_UI_INPUT + p)
                    elif isinstance(llm_param_binding[p], str):
                        llm_param_binding[p] = st.sidebar.text_input(p, key=SESSION_KEY_LLM_UI_INPUT + p)
                    else:
                        llm_param_binding[p] = st.sidebar.number_input(p, key=SESSION_KEY_LLM_UI_INPUT + p)


            st.button("Activate agent", on_click=activate_agent, use_container_width=True)

            st.subheader('Execution and Evaluation')

            # Function selection
            selected_function = st.sidebar.selectbox(
                'Function Settings',
                sorted(self.available_functions.keys()),
                key='selected_function')

            # File upload
            st.subheader('Schema')

            # Display file uploader
            if not "show_file_uploader" in st.session_state or st.session_state["show_file_uploader"]:
                st.session_state["file_uploader_visible"] = True
                #with st.chat_message(ROLE_AS):
                uploaded_file = st.file_uploader("Load Schema File", type=None, accept_multiple_files=False, 
                                            help="Uploads and reads a UTF-8 encoded json file and sets it as schema.",
                                            on_change=show_file_uploader)
                if uploaded_file:
                    text_content = ""
                    try:
                        stio = StringIO(uploaded_file.getvalue().decode("utf-8"))
                        text_content += stio.read()
                        stio.close()
                        uploaded_file.close()
                        st.button("Activate schema", on_click=activate_schema, args=(text_content,), use_container_width=True)
                        text_content = ""
                    except UnicodeDecodeError:
                        st.error("Unicode decode error")
            else:
                st.session_state["file_uploader_visible"] = False
                #st.rerun()

            st.subheader('Conversation')
            st.sidebar.button('Clear context', on_click=clear_chat_history, use_container_width=True)
            st.sidebar.button('Remove last prompt and response', on_click=remove_last_prompt_and_response, use_container_width=True)

            # end of sidebar context

        # Display messages part of the session state
        c = 0
        for message in st.session_state[SESSION_KEY_MESSAGES]:
            self.message_id += 1
            with st.chat_message(message[ROLE]):
                if MSG_FORMAT in message.keys():
                    if message[MSG_FORMAT] == MSG_FORMAT_INIT or message[MSG_FORMAT] == MSG_FORMAT_PROMPT:
                        placeholder = st.empty()
                        # insert prompt and add spaces before newlines to comply with markdown format
                        placeholder.write(message[MSG].replace("\n", "  \n"))
                    if message[MSG_FORMAT] == MSG_FORMAT_RESPONSE_LLM_TXT:
                        allow_rerun = False
                        if c >= len(st.session_state[SESSION_KEY_MESSAGES]) - 2 and not st.session_state[MSG_RERUN_LLM]:
                            allow_rerun = True
                        insert_llm_response(message[MSG], message[SRC], allow_rerun=allow_rerun)
                    if message[MSG_FORMAT] == MSG_FORMAT_RESPONSE_INT_IMG:
                        int_input = None
                        if SRC in message.keys():
                            int_input = message[SRC]
                        if c >= len(st.session_state[SESSION_KEY_MESSAGES]) - 2 and not st.session_state[MSG_RERUN_LLM]:
                            allow_rerun = True
                        insert_int_response(int_input, int_output=message[MSG], allow_rerun=allow_rerun)
                    if message[MSG_FORMAT] == MSG_FORMAT_RESPONSE_INT_TXT:
                        int_input = None
                        if SRC in message.keys():
                            int_input = message[SRC]
                        if c >= len(st.session_state[SESSION_KEY_MESSAGES]) - 2 and not st.session_state[MSG_RERUN_LLM]:
                            allow_rerun = True
                        insert_int_response(int_input, text_message=message[MSG], allow_rerun=allow_rerun)

                else:
                    print("Unknown format: " + str(message.keys()))
                    st.write(message[MSG])
            c += 1

        # read user prompt input
        user_prompt_input = st.chat_input() #st.chat_input(disabled=(len(api_key) < 1))
        
        # if there is no system-side prompt set for execution, execute the user input
        if not st.session_state[SESSION_KEY_NEXT_USER_PROMPT] and user_prompt_input:
            st.session_state[SESSION_KEY_NEXT_USER_PROMPT] = user_prompt_input

        if st.session_state[SESSION_KEY_NEXT_USER_PROMPT]:
            submit_user_prompt()

        if st.session_state[SESSION_KEY_RUN_AGENT]:
            submit_user_prompt()
