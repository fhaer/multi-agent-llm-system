import json
import re
import os
import subprocess
import datetime
from collections import Counter
import csv

class AgentManager:
    """Manages agents and their prompts based on a schema file"""


    def __init__(self, execution_engine):

        self.execution_engine = execution_engine
        self.agents = []


    def setup_agents(self, schema_contents):

        print("Setup agents ...")

        # Parse schema file and initialize into prompt stack
        (agent_types, evaluation_functions, execution_functions, agents, llm_configurations, init_agent_id) = self.parse_schema(schema_contents)

        self.agent_types = agent_types
        self.agents = agents
        self.llm_configurations = llm_configurations

        # Setup agent functions
        self.execution_engine.initialize_functions(evaluation_functions, execution_functions, agents)

        # Setup agent-prompt stack with initial values
        self.execution_engine.initialize_agent_prompt_stack(init_agent_id, 0)

        return init_agent_id


    def initialize_agent(self, agent_id):
        self.execution_engine.initialize_agent_prompt_stack(agent_id, 0)


    def get_agents(self):
        return self.agents
    

    def get_agent(self):

        (agent_id, prompt_id) = self.execution_engine.get_agent_prompt_ids_by_index(0)
        agent = self.agents.get(agent_id, {})
        return agent


    def get_agent_prompt(self):

        (agent_id, prompt_id) = self.execution_engine.get_agent_prompt_ids_by_index(0)
        prompts = self.agents.get(agent_id, {}).get("prompts")
        agent = self.agents.get(agent_id, {})
        prompt_data = prompts[prompt_id]
        # set prompt data variables from agent data
        agent_data = self.agents.get(agent_id, {}).get("data", {})
        prompt_message = self.insert_template_variables(prompt_data.get("prompt"), agent_data)
        prompt_data["prompt"] = prompt_message
        return (agent, prompt_data)


    def get_next_alphabetical_agent_id(self, current_agent_id):
        sorted_keys = sorted(self.agents.keys())
        try:
            index = sorted_keys.index(current_agent_id)
            return sorted_keys[index + 1]
        except (ValueError, IndexError):
            return None
        

    def remove_agent_prompt(self):
        
        (agent_id, prompt_id) = self.execution_engine.pop_agent_prompt()

        return (agent_id, prompt_id)


    def set_next_agent_prompt(self):

        self.execution_engine.push_next_agent_prompt()
        self.execution_engine.remove_agent_prompt(1)


    def has_agent_prompt(self):

        return self.execution_engine.has_agent_prompt()
    

    def has_next_agent_prompt(self):

        return self.execution_engine.has_next_agent_prompt()
    

    def get_agent_type(self, id):
        if id in self.agent_types:
            return self.agent_types[id]
        return None
    

    def get_llm_configuration(self, id):
        if id in self.llm_configurations:
            return self.llm_configurations[id]
        return None


    def execute_actions(self, input):

        (agent, prompt) = self.get_agent_prompt()
        (output, data, append_output) = self.execution_engine.execute_actions(agent, prompt, input)

        return (output, data, append_output)


    def evaluate_result(self, result_input, data):
        
        (agent, prompt) = self.get_agent_prompt()
        (result_class, evaluation) = self.execution_engine.evaluate_result(agent, prompt, result_input, data)

        return (result_class, evaluation)
    

    def write_result_classes_evaluations(self):

        self.execution_engine.write_result_classes_evaluations()


    def insert_template_variables(self, template, data):

        output = template
        variables = re.findall(r"\[(.*?)\]", template)

        for var in variables:
            var_path = var
            keys = var_path.split("/")
            data_for_key = data
            for k in keys:
                data_for_key = data_for_key.get(k, {})
            if (isinstance(data_for_key, dict) or isinstance(data_for_key, list)) and data_for_key:
                output = output.replace(f"[{var_path}]", json.dumps(data_for_key, indent=4))
            elif data_for_key:
                output = output.replace(f"[{var_path}]", str(data_for_key))

        return output
    

    def parse_prompt_templates(self, agents):

        for agent in agents.values():

            prompt_data = agent.get("prompts", [])
            if "prompt-file" in agent:
                with open(agent["prompt-file"], encoding="utf-8") as file:
                    prompt_data += json.loads(file.read())

            prompt_template = agent.get("prompt-template", None)
            expected_class_template = agent.get("expected-class-template", None)
            expected_value_template = agent.get("expected-value-template", None)
            expected_pattern_template = agent.get("expected-pattern-template", None)

            if prompt_template:

                for prompt_dict in prompt_data:
                    promt_text = self.insert_template_variables(prompt_template, prompt_dict)
                    prompt_dict["prompt"] = promt_text
                    if expected_class_template:
                        expected = self.insert_template_variables(expected_class_template, prompt_dict)
                        prompt_dict["expected-class"] = expected
                    if expected_value_template:
                        expected = self.insert_template_variables(expected_value_template, prompt_dict)
                        prompt_dict["expected-value"] = expected
                    if expected_pattern_template:
                        expected = self.insert_template_variables(expected_pattern_template, prompt_dict)
                        prompt_dict["expected-pattern"] = expected

            agent["prompts"] = prompt_data


    def parse_schema(self, json_contents):

        data = json.loads(json_contents)
    
        # Extract agent types
        agent_types = {
            agent_type["id"]: agent_type for agent_type in data.get("agent-type", [])
        }
        
        # Extract evaluation functions
        evaluation_functions = {
            eval_func["id"]: eval_func for eval_func in data.get("functions", {}).get("evaluate", [])
        }
        
        # Extract execution functions
        execution_functions = {
            ex_func["id"]: ex_func for ex_func in data.get("functions", {}).get("execute", [])
        }

        # Extract and create agents according to their agent type
        agents = {
            agent["id"]: agent for agent in data.get("agents", [])
        }
        for agent_id in agents.keys():
            agent_type = agents[agent_id]["agent-type"]
            for k, v in agent_types[agent_type].items():
                agents[agent_id][k] = v

        # Extract LLM configurations
        llm_configurations = {
            llm_config["id"]: llm_config for llm_config in data.get("llm-configurations", [])
        }

        # Insert prompt templates with variables
        self.parse_prompt_templates(agents)

        # Set initial agent
        init_agents = data.get("agents", [])
        init_agent_id = None
        if len(init_agents) > 0:
            init_agent_id = init_agents[0]["id"]
        
        return agent_types, evaluation_functions, execution_functions, agents, llm_configurations, init_agent_id

