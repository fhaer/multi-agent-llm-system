import sys
import os
import re
from time import perf_counter_ns

import llm_api.llm_api_client as llm_api_client

API_ID_LIST = llm_api_client.LLM_API_IDS
INT_API_ID_LIST = []
LLM_API_ID_LIST = llm_api_client.LLM_API_IDS
LLM_BY_ID_PRECONFIGURED = llm_api_client.LLM_BY_ID 

LLM_UNSELECTED = '<Select>'
INT_UNSELECTED = '<Select>'

class ConversationManager:
    """Manages the selected agents and LLMs with parameters"""

    def __init__(self, api_keys, api_endpoints, llm_api_client, data_store):
        print("Load Conversation Manager ...")
        self.api_keys = api_keys
        self.api_endpoints = api_endpoints
        self.available_llms_loaded = False
        self.available_functions_loaded = False
        self.llm_api_client = llm_api_client
        self.data_store = data_store
        self.conversational_ui = None
        self.selected_llm_id = LLM_UNSELECTED
        self.selected_int_id = INT_UNSELECTED
        self.llm_parameters = None
        self.llm_parameters_default = None
        self.int_parameters = None
        self.int_parameters_default = None

    def set_conversational_ui(self, conversational_ui):
        self.conversational_ui = conversational_ui

    def select_llm(self, selected_llm_id):
        """
        If the given LLM was not selected before, it is set selected, LLM parameters are reset, and 
        True is returned; otherwise False is returned.
        """

        if selected_llm_id and self.selected_llm_id != selected_llm_id:
            self.selected_llm_id = selected_llm_id
            if selected_llm_id != LLM_UNSELECTED:
                print("Selected LLM:", selected_llm_id)
                self.selected_llm_api_id = self.available_llms[selected_llm_id]
                print("Reset LLM parameters")
                self.llm_parameters = None
                self.llm_parameters_default = None
                self.file_upload = None
            return True

        return False
    
    def is_llm_selected(self):
        return self.selected_llm_id != LLM_UNSELECTED
    
    def is_int_selected(self):
        return self.selected_int_id != INT_UNSELECTED

    def set_available_llms(self):
        """Sets available models from each API that is enabled by setting an API key or endpoint"""

        if not self.available_llms_loaded:
            self.available_llms_loaded = True
            self.llm_api_client.query_available_llms(self.api_keys, self.api_endpoints)
            self.available_llms = {LLM_UNSELECTED:''} | llm_api_client.LLM_BY_ID
            self.conversational_ui.set_available_llms(self.available_llms)

    def set_available_functions(self):
        """Sets available execution and evaluation functions"""

        if not self.available_functions_loaded:
            self.available_functions_loaded = True
            self.available_functions = {INT_UNSELECTED:''}
            self.conversational_ui.set_available_functions(self.available_functions)

    def initialize_llm(self, init_message, api_selected, api_key, api_endpoint):
        """Initialize LLM API or runtime"""

        if api_selected:
            self.llm_api_client.initialize_llm(
                self.selected_llm_id, self.selected_llm_api_id, self.llm_parameters, api_key, api_endpoint)
            self.data_store.reset_configuration(init_message)


    def set_llm_parameters(self, init_message):
        """
        Sets initial LLM parameters and initializes a LLM API or a local runtime. 
        Returns parameters as parameter binding to be connected to, e.g., UI controls.
        """

        if not self.llm_parameters:

            self.llm_parameters = {}

            # set default values for the selected LLM, running via API or a local runtime
            for api_id in LLM_API_ID_LIST:
                if self.selected_llm_id.startswith(api_id):
                    self.llm_parameters_default = llm_api_client.PARAMETER_DEFAULTS[api_id].copy()
                    self.llm_parameters = llm_api_client.PARAMETER_DEFAULTS[api_id].copy()
                    break

            # get API parameters
            api_key = ""
            api_endpoint = ""
            api_selected = False
            for api_id in LLM_API_ID_LIST:
                if self.selected_llm_id.startswith(api_id):
                    api_selected = True
                    if api_id in self.api_keys.keys():
                        api_key = self.api_keys[api_id]
                    if api_id in self.api_endpoints.keys():
                        api_endpoint = self.api_endpoints[api_id]
                    break

            self.initialize_llm(init_message, api_selected, api_key, api_endpoint)
            
        return self.llm_parameters

    def select_interpreter(self, selected_int_id):
        """
        If the given interpreter was not selected before, it is set selected, interpreter parameters are reset, and 
        True is returned; otherwise False is returned.
        """

        if self.selected_int_id != selected_int_id:
            self.selected_int_id = selected_int_id
            if selected_int_id != INT_UNSELECTED and self.selected_llm_id != LLM_UNSELECTED:
                print("Selected interpreter:", selected_int_id)
                print("Reset interpreter parameters")
                self.int_parameters = None
                self.int_parameters_default = None
            return True

        return False

    def set_interpreter_parameters(self):
        """
        Sets initial interpreter parameters and initializes an interpreter. 
        Returns parameters as parameter binding to be connected to, e.g., UI controls.
        """

        if not self.int_parameters:

            self.int_parameters = {}

        return self.int_parameters

    def enter_prompt(self, context, prompt):
        """
        Executes a prompt string with the given context as message array.
        Returns the response as tuple (items_wrapped, item_function) where item_function is a 
        lambda function extracting the wrapped response items.
        """
        print("Prompt:", prompt)

        # store LLM configuration and prompt
        self.data_store.set_llm_configuration(self.selected_llm_id, self.llm_parameters)
        self.data_store.set_interpreter_configuration(self.selected_int_id, self.int_parameters)
        self.data_store.insert_prompt(prompt)
        
        # run prompt with an API
        for api_id in LLM_API_ID_LIST:
            if self.selected_llm_id.startswith(api_id):

                print("LLM parameters:", self.llm_parameters)
                print("Interpreter parameters:", self.int_parameters)
                t_start = perf_counter_ns()
                (items_wrapped, item_function) = self.llm_api_client.request_run_prompt(context, prompt)
                break

        return (items_wrapped, item_function, t_start)
    
    def record_llm_response(self, llm_response, execution_duration):
        """
        Stores an LLM response and the execution time. 
        """
        self.data_store.insert_llm_response(llm_response, execution_duration)

    #def process_llm_response(self, llm_response):
    #    """
    #    Parses an LLM response. If an LLM response contains concrete syntax, it is parsed and returned, otherwise None. 
    #    """
    #   return output

    def clear_chat_history(self, init_message):
        self.llm_api_client.clear_returned_context()
        self.data_store.create_conversation(init_message)

    def remove_last_message(self):
        self.llm_api_client.clear_returned_context()
        self.data_store.insert_message("Last message removed")
