import json
import re
import os
import subprocess
import datetime
from collections import Counter
import csv

class ExecutionEngine:
    """Executes agent actions of execution and evaluation functions"""

    def __init__(self):

        self.agents = []
        self.agent_prompt_stack = []

        self.result_classes = {}
        self.evaluation_results = {}


    def initialize_functions(self, evaluation_functions, execution_functions, agents):
        self.evaluation_functions = evaluation_functions
        self.execution_functions = execution_functions
        self.agents = agents


    def initialize_agent_prompt_stack(self, agent_id, prompt_id):

        self.agent_prompt_stack = [ (agent_id, prompt_id) ]
        print("Prompt stack initialized with agent-id", agent_id, "and prompt-id", prompt_id)


    def get_agent_prompt_ids_by_index(self, index):

        (agent_id, prompt_id) = self.agent_prompt_stack[index]
        return (agent_id, prompt_id)


    def get_agent_prompt_ids(self):

        (agent_id, prompt_id) = self.agent_prompt_stack[0]
        return (agent_id, prompt_id)
    

    def has_agent_prompt(self):

        if len(self.agent_prompt_stack) > 0:
            (agent_id, prompt_id) = self.agent_prompt_stack[0]
            prompts = self.agents.get(agent_id, {}).get("prompts", [])
            if prompt_id < len(prompts):
                return True
            
        return False
            

    def has_next_agent_prompt(self):

        if len(self.agent_prompt_stack) > 0:
            (next_agent_id, next_prompt_id) = self.get_next_agent_prompt_ids()
            if next_agent_id is not None and next_prompt_id is not None:
                next_prompts = self.agents.get(next_agent_id, {}).get("prompts", [])
                if next_prompt_id < len(next_prompts):
                    return True
        
        return False


    def pop_agent_prompt(self):
        
        (agent_id, prompt_id) = self.agent_prompt_stack.pop()

        return (agent_id, prompt_id)


    def remove_agent_prompt(self, index):

        if len(self.agent_prompt_stack) >= index:
            del self.agent_prompt_stack[index]


    def push_next_agent_prompt(self):

        (agent_id, prompt_id) = self.get_next_agent_prompt_ids()
        if agent_id is not None and prompt_id is not None:
            self.agent_prompt_stack.insert( 0, (agent_id, prompt_id) )


    def get_next_agent_prompt_ids(self):

        agent_id = self.agent_prompt_stack[0][0]
        prompt_id = self.agent_prompt_stack[0][1]

        # load agent, prompt and current prompt
        agent = self.agents.get(agent_id, {})
        current_prompts = agent.get("prompts", [""])
        current_prompt = current_prompts[prompt_id]

        # set the prompts of the agent in charge to be next
        next_prompts = current_prompts

        # set the next prompt index
        next_prompt_id = prompt_id + 1

        # if a new agent is invoked, reset the prompt ID
        next_agent_id = agent_id
        if "invoke" in current_prompt:

            if "agent-of-type" in current_prompt["invoke"]:
                for a in self.agents.values():
                    if current_prompt["invoke"]["agent-of-type"] in a["agent-type"]:
                        if a["llm-configuration"] == self.agents[agent_id]["llm-configuration"]:
                            next_agent_id = a["id"]
            else:
                next_agent_id = current_prompt["invoke"]["agent-id"]

            next_prompt_id = current_prompt["invoke"]["prompt-id"]

            # message passing of data to next agent
            pass_data_keys = current_prompt["invoke"]["data-keys"]
            agent_data =  self.agents.get(agent_id, {}).get("data", {})
            next_agent_data = self.agents.get(next_agent_id, {}).get("data", {})
            for data_key in pass_data_keys:
                next_agent_data[data_key] = agent_data.get(data_key, "")

        # if a continuation is specified, retrieve the next prompt ID and set it
        if "continue" in current_prompt:
            continue_cmd = str(current_prompt["continue"])
            # break keyword: stop
            if continue_cmd == "break":
                next_prompt_id = None
                next_agent_id = None
            else:
                # continue with given prompt id
                for i, prompt in enumerate(next_prompts):
                    if "id" in prompt and str(prompt["id"]) == continue_cmd:
                        next_prompt_id = i
                        break

        return (next_agent_id, next_prompt_id)


    def get_execution_functions(self):
        return self.execution_functions
    

    def get_evaluation_function(self):
        return self.evaluation_functions
    

    def insert_data_variables(self, function_template, data):

        output = function_template
        variables = re.findall(r"\[(.*?)\]", function_template)

        for var in variables:
            var_path = var
            keys = var_path.split("/")
            data_for_key = data
            for k in keys:
                data_for_key = data_for_key.get(k, {})
            if (isinstance(data_for_key, dict) or isinstance(data_for_key, list)) and data_for_key:
                output = output.replace(f"[{var_path}]", json.dumps(data_for_key, indent=4))
            elif data_for_key:
                output = output.replace(f"[{var_path}]", str(data_for_key))

        return output


    def execute_function(self, ex_function, cmd, data, agent, output, append_output):
        """Execute a single function with provided command and data."""

        print("Run subprocess:", cmd)
        result = subprocess.run(cmd, shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)

        stdout = str(result.stdout).strip()
        stderr = str(result.stderr).strip()
        exit_status = result.returncode

        if ex_function.get("pass-stdout", False):
            output = stdout
        elif ex_function.get("pass-sterr", False):
            output = stderr
        elif ex_function.get("pass-exit-status", False):
            output = exit_status

        if ex_function.get("append-output", False):
            append_output = ex_function["append-output"]

        if not ex_function.get("assert-stdout", None) is None:
            if stdout != ex_function["assert-stdout"]:
                error = f"Error: Stdout assertion {ex_function["assert-stdout"]} failed for command {cmd}. Stdout: {stdout} Stderr: {stderr}"
                print(error)
                if "on-error" in agent and ["on-error"] == "break":
                    raise Exception(error)

        if not ex_function.get("assert-stderr", None) is None:
            if stdout != ex_function["assert-stderr"]:
                error = f"Error: Stderr assertion {ex_function["assert-stderr"]} failed for command {cmd}. Stdout: {stdout} Stderr: {stderr}"
                print(error)
                if "on-error" in agent and agent["on-error"] == "break":
                    raise Exception(error)
            
        if not ex_function.get("assert-exit-status", None) is None:
            if exit_status != ex_function["assert-exit-status"]:
                error = f"Error: Exit status assertion {ex_function["assert-exit-status"]} failed with status {exit_status} for command {cmd}. Stdout: {stdout} Stderr: {stderr}"
                print(error)
                if "on-error" in agent and agent["on-error"] == "break":
                    raise Exception(error)
            
        if not ex_function.get("set-stdout", None) is None:
            key = ex_function["set-stdout"]
            data[key] = stdout

        if not ex_function.get("set-stderr", None) is None:
            key = ex_function["set-stderr"]
            data[key] = stderr
    
        if not ex_function.get("set-exit-status", None) is None:
            key = ex_function["set-exit-status"]
            data[key] = exit_status
        
        return (output, data, append_output)


    def execute_actions(self, agent, prompt, input):
        """Execute multiple actions and return output, data, and append status."""

        # get execution function from agent, extend with data from prompt
        actions = agent.get("actions", []).copy()
        actions += prompt.get("actions", [])

        # get execution data from agent, extend with data from prompt
        data = agent.get("data", {})
        for k, v in prompt.get("data", {}).items():
            data[k] = v

        # process input and return as output
        output = input

        # appended the processed output to the context
        append_output = False

        # execute actions
        for ex_function_id in actions:

            if ex_function_id in self.execution_functions:

                print(ex_function_id)
                ex_function = self.execution_functions[ex_function_id]

                cmd_template = ex_function.get("command", "")
                output_file = ex_function.get("output-file", "")

                if cmd_template:
                    cmd = self.insert_data_variables(cmd_template, data)
                    # process input variable
                    cmd = cmd.replace(f"[input]", input)
                    (output, data, append_output) = self.execute_function(ex_function, cmd, data, agent, output, append_output)

                if not ex_function.get("set-input", None) is None:
                    key = ex_function["set-input"]
                    data[key] = input

                if not ex_function.get("set-output", None) is None:
                    key = ex_function["set-output"]
                    data[key] = output

                if output_file:
                    output_file = self.insert_data_variables(output_file, data)
                    with open(output_file, "w") as file:
                        file.write(output)

        return (output, data, append_output)


    def determine_evaluation_functions(self, agent, prompt, prompt_id):
        eval_functions = {}

        if "evaluate" in prompt:
            eval_functions[prompt["evaluate"]] = prompt.get("expected-class", None)
            if "evaluate" in agent:
                eval_functions[agent["evaluate"]] = agent.get("expected-class", None)
        elif "evalute" in agent:
            if "expected-class" in prompt:
                eval_functions[agent["evaluate"]] = prompt["expected-class"]
            elif "expected-class" in agent:
                eval_functions[agent["evaluate"]] = agent["expected-class"]
        elif "expected-value" in prompt:
            id = f"eval-p-{prompt_id}"
            eval_functions[id] = True
            self.evaluation_functions[id] = {
                "id": id,
                "result-classes": [
                    {"class": True, "value": prompt["expected-value"], "eval-expected": "correct", "eval-unexpected": "incorrect"},
                    {"class": False, "pattern": ".*", "eval-expected": "correct", "eval-unexpected": "incorrect"}
                ]
            }
        elif "expected-pattern" in prompt:
            id = f"eval-p-{prompt_id}"
            eval_functions[id] = True
            self.evaluation_functions[id] = {
                "id": id,
                "result-classes": [
                    {"class": True, "pattern": prompt["expected-pattern"], "eval-expected": "correct", "eval-unexpected": "incorrect"},
                    {"class": False, "pattern": ".*", "eval-expected": "correct", "eval-unexpected": "incorrect"}
                ]
            }
        else:
            id = f"eval-p-{prompt_id}"
            eval_functions[id] = True
            self.evaluation_functions[id] = {
                "id": id,
                "result-classes": [
                    {"class": True, "pattern": ".*", "eval-expected": "correct", "eval-unexpected": "incorrect"}
                ]
            }
        
        return eval_functions

    def execute_evaluation(self, eval_function_id, expected_class, result_input, data):
        result_class = None
        evaluation = None
        
        if eval_function_id in self.evaluation_functions:
            eval_function = self.evaluation_functions[eval_function_id]
            result = result_input if "result-data-key" not in eval_function else data[eval_function["result-data-key"]]
            
            for class_data in eval_function.get("result-classes", []):
                if "value" in class_data and (
                    (isinstance(result, str) and any(class_data["value"] in line for line in result.strip().splitlines()))
                    or (class_data["value"] == result)
                ):
                    result_class = class_data["class"]
                elif "pattern" in class_data and re.search(class_data["pattern"], result, re.DOTALL):
                    result_class = class_data["class"]
                
                if result_class is not None and expected_class is not None:
                    evaluation = class_data["eval-expected"] if str(result_class) == str(expected_class) else class_data["eval-unexpected"]
                    break
        
        return result_class, evaluation

    def store_evaluation_results(self, agent_id, prompt_id, eval_function_id, result_class, evaluation):
        self.result_classes.setdefault(agent_id, {}).setdefault(prompt_id, {})[eval_function_id] = result_class
        self.evaluation_results.setdefault(agent_id, {}).setdefault(prompt_id, {})[eval_function_id] = evaluation

    def evaluate_result(self, agent, prompt, result_input, data):
        agent_id, prompt_id = self.get_agent_prompt_ids()
        eval_functions = self.determine_evaluation_functions(agent, prompt, prompt_id)
        
        result_class, evaluation = None, None
        for eval_function_id, expected_class in eval_functions.items():
            result_class, evaluation = self.execute_evaluation(eval_function_id, expected_class, result_input, data)
            self.store_evaluation_results(agent_id, prompt_id, eval_function_id, result_class, evaluation)
        
        return result_class, evaluation


    def write_results_to_csv(self, results, class_keys, evaluation_keys):
        """Writes the collected results to CSV files."""
        timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
        csv_filename = f"results_{timestamp}_by_agent.csv"
        fieldnames_results = ["ID"] + sorted(class_keys) + sorted(evaluation_keys)
        
        with open(csv_filename, mode="w", newline="") as file:
            writer = csv.DictWriter(file, fieldnames=fieldnames_results)
            writer.writeheader()
            writer.writerows(results)
        print(f"Results saved to {csv_filename}")
        
        # Transpose data
        transposed_data = [[key] + [result.get(key, 0) for result in results] for key in fieldnames_results]
        transposed_csv_filename = f"results_{timestamp}_by_evaluation.csv"
        
        with open(transposed_csv_filename, mode="w", newline="") as file:
            writer = csv.writer(file)
            writer.writerows(transposed_data)
        print(f"Results saved to {transposed_csv_filename}")
        

    def write_prompts_to_csv(self, prompts):
        """Writes the transformed prompt results to a CSV file."""
        timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
        prompts_csv_filename = f"results_{timestamp}_by_prompt.csv"
        agent_ids = [entry["ID"] for entry in prompts]
        header = ["Prompt ID"] + [f"{agent} R" for agent in agent_ids] + [f"{agent} E" for agent in agent_ids]
        
        rows = []
        for i in range(len(prompts)):
            row = [i]
            for agent_id in agent_ids:
                result_key = f"{agent_id}-{i} result"
                evaluation_key = f"{agent_id}-{i} evaluation"
                row.extend([prompts[i].get(result_key, "").replace("Result ", ""),
                            prompts[i].get(evaluation_key, "").replace("Evaluation ", "")])
            rows.append(row)
        
        with open(prompts_csv_filename, mode="w", newline="") as file:
            writer = csv.writer(file)
            writer.writerow(header)
            writer.writerows(rows)
        print(f"Results saved to {prompts_csv_filename}")
        

    def write_result_classes_evaluations(self):
        
        n_results_by_class_total = Counter()
        n_results_by_evaluation_total = Counter()
        results = []
        prompts = []
        class_keys = set()
        evaluation_keys = set()

        for agent_id in self.agents.keys():
            agent_data = {"ID": agent_id}
            prompt_data = {"ID": agent_id}

            if agent_id in self.result_classes:
                for prompt_id, eval_functions in self.result_classes[agent_id].items():
                    n_results_by_class = Counter(eval_functions.values())
                    n_results_by_class_total += n_results_by_class
                    for k, v in n_results_by_class.items():
                        result_label = f"Result {k}"
                        agent_data[result_label] = agent_data.get(result_label, 0) + v
                        prompt_data[f"{agent_id}-{prompt_id} result"] = result_label
                        class_keys.add(result_label)

            if agent_id in self.evaluation_results:
                for prompt_id, eval_functions in self.evaluation_results[agent_id].items():
                    n_results_by_evaluation = Counter(eval_functions.values())
                    n_results_by_evaluation_total += n_results_by_evaluation
                    for k, v in n_results_by_evaluation.items():
                        evaluation_label = f"Evaluation {k}"
                        agent_data[evaluation_label] = agent_data.get(evaluation_label, 0) + v
                        prompt_data[f"{agent_id}-{prompt_id} evaluation"] = evaluation_label
                        evaluation_keys.add(evaluation_label)

            results.append(agent_data)
            prompts.append(prompt_data)
        
        # Append total results
        total_data = {"ID": "TOTAL"}
        for k in class_keys:
            total_data[k] = n_results_by_class_total.get(k.replace("Result ", ""), 0)
        for k in evaluation_keys:
            total_data[k] = n_results_by_evaluation_total.get(k.replace("Evaluation ", ""), 0)
        results.append(total_data)
        
        self.write_results_to_csv(results, class_keys, evaluation_keys)
        self.write_prompts_to_csv(prompts)
        
        print(json.dumps(results, indent=4))
        print(json.dumps(prompts, indent=4))
