import subprocess

def determine_cidr(ip):
    ip_info = subprocess.check_output(['ip', 'addr', ip])
    ip_address = ip_info.decode().split()[1]
    
    route_info = subprocess.check_output(['ip', 'route'])
    for line in route_info.decode().splitlines():
        if f"{ip_address} is" in line:
            _, mask = line.split()
            break
    
    cidr = 0
    for octet in mask.split('.'):
        if octet == '255':
            continue
        elif octet == '254':
            cidr += 7
            break
        else:
            return f"{cidr}.{octet}"
    
    return f"32.0.0.0"

def scan_web_ports(ip):
    ports_to_check = [
        80, 443, 22, 53, 25, 161, 123,
        79, 143, 110, 161, 123, 21, 23
    ]
    
    cmd = f'nmap -n -sV -p {", ".join(map(str, ports_to_check))} {ip}'
    result = subprocess.check_output(cmd, shell=True)
    
    port_info = {}
    for line in result.decode().splitlines():
        if line.strip() and line.startswith('Host'):
            host = line.split()[0]
            for p_line in result.decode().splitlines()[result.decode().splitlines().index(line)+1:]:
                if p_line.strip() and p_line.startswith(f'{host}:'):
                    port, state = p_line.split()
                    protocol = 'http' if port == 80 or port == 443 else 'other'
                    service = ''
                    for http_header in result.decode().splitlines():
                        if http_header.startswith('HTTP headers'):
                            service = http_header.split()[1]
                            break
                    port_info[port] = {
                        'state': state,
                        'protocol': protocol,
                        'service': service
                    }
    return port_info

cidr = determine_cidr('192.168.1.5')
scan_results = scan_network(cidr)

for ip in scan_results:
    print(f"\nHost: {ip}")
    if scan_results[ip]:
        print("Web Port Scan:")
        for port, details in scan_results[ip].items():
            protocol = 'http' if port in [80, 443] else 'other'
            service = details['service']
            state = details['state']
            print(f"Port {port} ({protocol}) - Service: '{service}', State: {state}")