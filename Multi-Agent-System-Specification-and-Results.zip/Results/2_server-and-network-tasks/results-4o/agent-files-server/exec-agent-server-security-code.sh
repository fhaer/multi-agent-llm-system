#!/bin/bash

# Create a system security report using lynis and output the result to the console
sudo lynis audit system