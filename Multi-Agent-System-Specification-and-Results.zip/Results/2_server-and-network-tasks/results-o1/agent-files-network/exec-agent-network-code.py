import nmap

def detailed_scan(hosts):
    scanner = nmap.PortScanner()
    # Define web-related ports commonly used by web services
    web_ports = '80,443,8080,8000,8443'
    print("Performing detailed scans on web-related ports...")
    for host in hosts:
        print(f"\nScanning host {host}...")
        # Perform a detailed scan with OS and service detection
        scanner.scan(hosts=host, ports=web_ports, arguments='-A -Pn')
        # Check if the host is up
        if host in scanner.all_hosts():
            print(f"Host: {host}")
            print(f"State: {scanner[host].state()}")
            # OS Detection results
            if 'osmatch' in scanner[host]:
                print("\nOS Details:")
                for osmatch in scanner[host]['osmatch']:
                    print(f"Name: {osmatch['name']}, Accuracy: {osmatch['accuracy']}%")
            else:
                print("OS details not available.")
            # Service Detection results
            for proto in scanner[host].all_protocols():
                print(f"\nProtocol: {proto}")
                lport = scanner[host][proto].keys()
                for port in sorted(lport):
                    service = scanner[host][proto][port]
                    product = service.get('product', '')
                    version = service.get('version', '')
                    extrainfo = service.get('extrainfo', '')
                    service_info = f"{service['name']} {product} {version} {extrainfo}".strip()
                    print(f"Port: {port}\tState: {service['state']}\tService: {service_info}")
        else:
            print(f"Host {host} is down or not responding.")

if __name__ == "__main__":
    hosts_to_scan = ['10.11.1.0', '10.11.1.1', '10.11.1.24', '10.11.1.33']
    detailed_scan(hosts_to_scan)